java  -jar learner.jar  $1.txt $1.grammar $1.dot $1.test $1.tex
pdflatex $1.tex
/usr/local/bin/fdp -Tpdf $1.dot -o $1.dot.pdf
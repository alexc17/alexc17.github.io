function [data,labelArray] = readOmphalosFile(filename, vocab)

% Reads an omphalos file and turns it into a cell array on integer vectors
% vocab is a filename with all of the strings in it 
% This is very crude and inefficient.

vocabFid = fopen(vocab);

if(vocabFid == -1)
       vocab
    error(' file not found');
end

vocabArray2 = textscan(vocabFid,'%s');
vocabArray=vocabArray2{1};

fid = fopen(filename);
tline = fgetl(fid);
% The line should be of the form 280 5 
% number of data points and then the size of the vocabulary
[DataSize,VocabSize] = strread(tline,'%u %u');
disp(sprintf('Loading file with vocabulary size %d and data size %d', VocabSize, DataSize));
%dataArray = cell(DataSize,1);
labelArray = ones(DataSize,1);
for i=1:DataSize
    tline = fgetl(fid);
    [datas] = strread(tline,'%s');
    label = strread(datas{1},'%d');
    length = strread(datas{2},'%u');
    sentence = ones(1,length);
    for j=1:length
        sentence(1,j) = convertVocab(datas{j+2},VocabSize, vocabArray);
    end
    labelArray(i) = label;
    dataArray{i} = sentence;
end
data = dataArray';

function [V] = convertVocab(myString,VocabSize, vocabArray)
for k = 1:VocabSize
    if strcmp(myString,vocabArray{k,1})
        V = k;
        return;
    end
end
error('String not found');

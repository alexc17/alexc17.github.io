function [Residuals] = test(Representation, test)

% Computes the residual of the data with respect to this representation
% Written by alexc based on code by John Shawe-Taylor and Nello Cristianini
% Code in book is incorrect.

train = Representation.train;
kernel = Representation.kernel;
param = Representation.kernelParams;

n = size(train,1);
m = size(test,1);

for i = 1:n
    for j = 1:m
           v = kernel(train{i},test{j},param);      
           KT(i,j) = v;
    end
end

for i = 1:m
           v = kernel(test{i},test{i},param);
           TT(i,i) = v;
         %  TT(i,j) = v;
end

% Now translate these
F = sum(KT)/n;
D = Representation.D;
E = Representation.E;
V = Representation.V;
invL = diag(1./diag(Representation.L));

% KT2 is KT translated
KT2 = KT - D' * ones(1,m) - ones(n,1) * F + E * ones(n,m);
F2 = ones(m,1) * F;

TT2 = TT - F2' - F2 + E * ones(m,m);

TTNew = KT2' * V * invL * V' * KT2;

Residuals = diag(TT2) - diag(TTNew);



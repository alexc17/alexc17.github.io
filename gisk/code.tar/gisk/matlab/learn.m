function [Representation, Residuals] = learn(train, kernel, param)

% Computes a representation of the training data
% and the residuals of the data which should be close to zero.
% Arguments are a cell array of training data, a function handle,
% kernel hyperparameter.
% Written by Alex Clark but heavily based on 
% John Shawe-Taylor and Nello Cristianini's code
% Jan 11 2006.

n = size(train,1);
for i = 1:n
    for j = i:n
           v = kernel(train{i},train{j},param);
           K(j,i) = v;
           K(i,j) = v;
    end
end

% K is the Gram matrix
D = sum(K)/n;
E = sum(D)/n;
J = ones(n,1) * D;

K2 = K - J - J' + E * ones(n,n);
% K2 is the translated kernel.


k = rank(K2);
[V,L] = eigs(K2,k,'LM');
% Debugging

fullEigenvalues = eig(K2);

invL = diag(1./diag(L));
sqrtL = diag(sqrt(diag(L)));
invsqrtL = diag(1./diag(sqrtL));
Knew = K2' * V * invL * V' * K2;
% lengths of translated vectors 
% mahalanobis = sqrt(diag(K2' * V * invL * invL * V' * K2))
Representation.V = V;
Representation.L = L;
Representation.D = D;
Representation.E = E;
Representation.eigs = fullEigenvalues;
Representation.rank = k;
Representation.train = train;
Representation.Knew = Knew;
Representation.kernel = kernel;
Representation.kernelParams = param;

Residuals = diag(K2) - diag(Knew);





function [kernel] = gapplus(s,t,param)

kernel = KSubsequences(s,t,1) + GapWeightedSubsequences(s,t,param);
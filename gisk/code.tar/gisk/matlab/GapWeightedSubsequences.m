
% Gap-weighted subsequence kernels
%
% Copied from Shaw-Taylor, page 369, (pseudo) Code Fragment 11.3
% Typed in and adapted for Matlab by Christophe Costa Florencio
% Tweaked by Alexc 12 Jan 2006

function [kernel] = GapWeightedSubsequences(s, t, param)

p = param.p;
lambda = param.lambda;

if p == 1
    'Please use values >1 for p'
else

    n = length(s);
    m = length(t);

    dps = zeros(n, m);

    for i = 1:n
        for j = 1:m
            if s(i) == t(j)
                dps(i, j) = lambda^2;
            end
        end
    end

    % The array dp must have a 'border' of zeroes (top row and leftmost column)
    % because of addressing dp(i - 1, j), dp(i, j - 1), dp(i - 1, j - 1)

    dp = zeros(n + 1, m + 1);

    for l = 2:p
        kern(l) = 0;
        for i = 2:n + 1
            for j = 2:m + 1
                % The indices in dps(i - 1, j - 1) are like this because of offset for
                % border in dp
                dp(i, j) = dps(i - 1, j - 1) + lambda * dp(i - 1, j) + lambda * dp(i, j - 1) - lambda^2 * dp(i - 1, j - 1);
                % The indices in s(i - 1), t(j - 1) again because of border
                if s(i - 1) == t(j - 1)
                    dps(i - 1, j - 1) = lambda^2 * dp(i - 1, j - 1);
                    kern(l) = kern(l) + dps(i - 1, j - 1);
                end
            end
        end
    end

    kernel = kern(p);
end
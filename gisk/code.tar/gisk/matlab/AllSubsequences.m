function [Kappa] = AllSubsequences(s,t, param)
% All subsequences kernel
% Taken from kernel methods for pattern analysis by JST and Nello
% Typed in by Alex Clark


n = length(s);
m = length(t);

dp = ones(n+1,m+1);
p = [];
% epsilon epsilon matches
%dp(1,1) = 1;
%for j = 1:m
%    dp(1,j+1) = 1;
%end
%dp(1,1) = 0;
for i = 1:n
    si = s(i);
    last = 1;
    p(1) = 0;
    for k = 1:m
        tk = t(k);
        p(k+1) = p(last);
        if tk == si
            p(k+1) = p(last) + dp(i,k);
            last = k+1;
        end
    end
    % precomputed p
    for k = 1:m
        dp(i+1,k+1) = dp(i,k+1) + p(k+1);
    end
end
dp;
Kappa = dp(n+1,m+1)-1;

        
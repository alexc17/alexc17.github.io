% Non - contiguous subsequences of length up to k kernel
% Taken from kernel methods for pattern analysis by JST and Nello
% Typed in by Alex Clark


function [Kappa] = AllKSubsequences(s,t,p)

n = length(s);
m = length(t);

Kappa = 0;
dp = ones(n+1,m+1);

for l = 1:p
    dpr = dp;
    dp = zeros(n+1,m+1);
    for i=1:n
        si = s(i);
        last = 0;
        pp(1) = 0;
        for k=1:m
            tk = t(k);
            pp(k+1) = pp(last+1);
            if tk == si
                pp(k+1) = pp(last+1) + dpr(i,k);
                last = k;
            end
        end
        for k =1:m
            dp(i+1,k+1) = dp(i,k+1) + pp(k+1);
        end
    end
    Kappa = Kappa + dp(n+1,m+1);
end



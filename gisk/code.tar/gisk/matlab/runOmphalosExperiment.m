function [errorCounts] = runOmphalosExperiment(vocabFile, trainingFile, testFile, kernel, param)

% function [errorCounts] = runOmphalosExperiment(vocabFile, trainingFile, testFile, kernel, param)
% 
% this function runs a complete experiment on omphalos format data.
% Using the algorithm described in "Languages as Hyperplanes" by
% Alex Clark, Christophe Costa Florencio, and Chris Watkins, in ECML 2006
% 
% INPUTS
% filename of vocabulary file
% filename of training data ( should be positive only or it won't work)
% filename of test data
% handle of kernel
% kernel hyperparameters
%
% OUTPUTS
%
% Returns a vector of four values [ falseNeg, correctNeg, correctPos,
% falsePos]
%
% Author: Alex Clark alexc@cs.rhul.ac.uk
%



[data,labels] = readOmphalosFile(trainingFile,vocabFile);
[testData,trueLabels] = readOmphalosFile(testFile,vocabFile);
[rep,trainingResiduals] = learn(data,kernel,param);
disp(sprintf('Rank of hyperplane %d', rep.rank));
[testResiduals] = test(rep,testData);
% if the residuals are small then they are in the language
predictedLabels = testResiduals < 0.001;
errors = 2 * predictedLabels - trueLabels;
% 2 is falsePositive
% 1 is correctPositive
% 0 is correct negative
% -1 is falseNegative
errorCounts = histc(errors, [ -1 0 1 2]);
fn = errorCounts(1);
cn = errorCounts(2);
cp = errorCounts(3);
fp = errorCounts(4);

disp(sprintf('False positive error rate  %f', fp/(fp + cn) )); 
disp(sprintf('False negative error rate  %f', fn/(fn + cp) ));
%I = find(errors==2)  % For finding false positives
%testData{I}